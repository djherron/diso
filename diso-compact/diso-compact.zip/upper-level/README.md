# README

Ontology **DUL** is a variant of **DOLCE**, so if these align well it may not be of interest.

CAUTION: Beware of **SUMO** --- the ontology file is 37 MB!

NOTE: Ontology **GFO-Bio** is part of DISO because of the strong theme of bio in other OAEI tracks. In theory, bio ontologies should map into (subsumptively) this **upper-level** ontology for the Bio-Medical domain, a variant of **GFO**. The file `gfo-bio-merged.ttl` contains a merge of **GFO-Bio** AND its import of **GFO**.



