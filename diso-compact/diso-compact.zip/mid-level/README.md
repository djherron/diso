# README

The **CCO** mid-level ontologies are all targeted at extending the upper-level ontology **BFO** towards distinct domains. So we it would be surprising if there was significant overlap between them. I would give such an exploration low priority.

Overlaps between individual CCO mid-level ontologies and the `ies-core.ttl` mid-level ontology are more likely to arise, I suspect. I think that's where the alignment exploration should focus.

An easy way to do this might be to align `CommonCoreOntologiesMerged.ttl` with `ies-core.ttl`.

`CommonCoreOntologiesMerged.ttl` contains a merge of all 11 CCO ontologies and the BFO upper-level ontology. So, by aligning it with `ies-core.ttl`, we should look for two things:
* overlap of the mid-level `ies-core.ttl` with the mid-level CCO ontologies
* hopefully, a subsumptive alignment between mid-level `ies-core.ttl` and upper-level BFO

We could also check how well the mid-level `ies-core.ttl` maps in subsumptively to all the other upper-level ontologies.  We know it maps into `ies-top.ttl`, because they were designed that way.

Note also: since `CommonCoreOntologiesMerged.ttl` contains a merge of all 11 CCO ontologies and the BFO upper-level ontology, it should contain 11 gold-standard alignments between the 11 CCO modules and BFO. If we can extract those alignments, we'd have gold-standard reference alignments.


